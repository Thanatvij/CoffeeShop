document.addEventListener('DOMContentLoaded', function() {
  const API_URL = 'http://localhost:3000/api';

  function showMessage(message, type) {
    const existingMessage = document.querySelector('.auth-message');
    if (existingMessage) existingMessage.remove();

    const msg = document.createElement('div');
    msg.className = `auth-message ${type}`;
    msg.textContent = message;
    msg.style.cssText = `
      padding: 12px 20px;
      margin: 15px 0;
      border-radius: 4px;
      font-size: 14px;
      text-align: center;
      ${type === 'error' ? 'background-color: #ffe0e0; color: #a94442; border: 1px solid #f5c6cb;' :
        'background-color: #e0ffe0; color: #2d6a4f; border: 1px solid #c3e6cb;'}
    `;

    const container = document.querySelector('.auth-form-container');
    const form = document.querySelector('.auth-form');
    if (container && form) container.insertBefore(msg, form);
    else document.body.insertBefore(msg, document.body.firstChild);

    setTimeout(() => msg.remove(), 5000);
  }

  function setFormLoading(form, isLoading) {
    const btn = form.querySelector('button[type="submit"]');
    const inputs = form.querySelectorAll('input');
    btn.disabled = isLoading;
    btn.textContent = isLoading ? 'Processing...' : form.id === 'loginForm' ? 'Login' : 'Create Account';
    inputs.forEach(input => input.disabled = isLoading);
  }

  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      const email = document.getElementById('username')?.value.trim();
      const password = document.getElementById('password')?.value;
      if (!email || !password) return showMessage('Please fill in all fields', 'error');

      setFormLoading(loginForm, true);
      try {
        const response = await fetch(`${API_URL}/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });
        const text = await response.text();
        let data = {};
        try { data = JSON.parse(text); } catch {}

        if (response.ok) {
          localStorage.setItem('user', JSON.stringify(data || { email }));
          showMessage('Login successful! Redirecting...', 'success');
          setTimeout(() => window.location.href = 'index.html', 1500);
        } else {
          const message = data.message || 'Invalid email or password';
          showMessage(message, 'error');
        }
      } catch {
        showMessage('Connection error. Please try again.', 'error');
      } finally {
        setFormLoading(loginForm, false);
      }
    });
  }

  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      const fullName = document.getElementById('fullname')?.value.trim() || document.getElementById('full-name')?.value.trim();
      const email = document.getElementById('email')?.value.trim();
      const username = document.getElementById('username')?.value.trim();
      const password = document.getElementById('password')?.value;
      const confirmPassword = document.getElementById('confirm-password')?.value;

      if (!username || !email || !password || !confirmPassword)
        return showMessage('All fields are required', 'error');
      if (password !== confirmPassword)
        return showMessage('Passwords do not match', 'error');
      if (password.length < 6)
        return showMessage('Password must be at least 6 characters long', 'error');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        return showMessage('Please enter a valid email address', 'error');

      setFormLoading(registerForm, true);
      try {
        const requestBody = { username, email, password, ...(fullName && { fullName }) };
        const response = await fetch(`${API_URL}/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody)
        });
        const data = await response.json();

        if (response.ok) {
          showMessage('Registration successful! Redirecting to login...', 'success');
          setTimeout(() => window.location.href = 'login.html', 1500);
        } else {
          showMessage(data.message || 'Registration failed', 'error');
        }
      } catch {
        showMessage('Connection error. Please try again.', 'error');
      } finally {
        setFormLoading(registerForm, false);
      }
    });
  }

  function checkAuthStatus() {
    try {
      const user = JSON.parse(localStorage.getItem('user') || 'null');
      if (user) {
        const authButtons = document.querySelector('.auth-buttons');
        if (authButtons) {
          authButtons.innerHTML = `
            <span class="user-greeting">Hello, ${user.username}</span>
            <a href="#" class="auth-btn logout-btn" id="logoutBtn">Logout</a>
          `;
          document.getElementById('logoutBtn')?.addEventListener('click', e => {
            e.preventDefault();
            localStorage.removeItem('user');
            showMessage('Logged out successfully', 'success');
            setTimeout(() => window.location.reload(), 1000);
          });
        }
      }
    } catch {
      localStorage.removeItem('user');
    }
  }

  checkAuthStatus();

  const style = document.createElement('style');
  style.textContent = `
    .auth-message { border-radius: 6px; font-family: inherit; transition: all 0.3s ease; }
    .auth-message.error { background-color: #fee; color: #c33; border: 1px solid #fcc; }
    .auth-message.success { background-color: #efe; color: #363; border: 1px solid #cfc; }
    .user-greeting { margin-right: 15px; color: #8B4513; font-weight: 500; }
    .logout-btn { background-color: #8B4513 !important; color: white !important; }
    .logout-btn:hover { background-color: #654321 !important; }
    .auth-form button:disabled { opacity: 0.6; cursor: not-allowed; }
  `;
  document.head.appendChild(style);
});
