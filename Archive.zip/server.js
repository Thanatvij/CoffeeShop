const uri = "mongodb+srv://premch:Premchai512488@cluster0.ggfuffo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const path = require('path');
const cors = require('cors');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
  origin: 'http://localhost:5500', // or wherever your frontend is hosted
  credentials: true
}));

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'yourSecretKey', // Change to a strong secret in production
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } 
}));

// Routes
app.use('/api', authRoutes);

// MongoDB connection
mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

mongoose.connection.on('connected', () => {
  console.log('✅ Database connected successfully');
  app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
});

mongoose.connection.on('error', (err) => {
  console.error('❌ Database connection error:', err);
});

mongoose.connection.on('disconnected', () => {
  console.log('⚠️ Database disconnected');
});